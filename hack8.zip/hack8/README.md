echo "Hahahahah "
พิมพ์ sh DH.sh
ใส่รหัส
เลือกอันทีเลือกอันที่จะใช้
จบ ,
อย่าลืมกดติดตามช่อง Hacker TH.
         Facebook : ไม่มี ตัวตน & Not exist