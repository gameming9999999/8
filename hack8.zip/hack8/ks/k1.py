import os, sys, time
from time import sleep as timeout
def restart_program():
        python = sys.executable
        os.execl(python, python, * sys.argv)
        curdir = os.getcwd()
os.system("clear")
print "\033[36;1m"
os.system("figlet Login Tools")
print "\033[32;1mAuthor   : NothingYT"
print "\033[36;1mGroup    : Nothing"
print "\033[36;1mFacebook : Naranan Leejaroen            "
print "\033[36;1mVersion  : 8                "
print
print "\033[36;1mlink Password > \033[32;1mhttps://pastebin.com/2UrnUZAK "
print 
A = raw_input("\033[34;1m[*] \033[32;1mPassword :  \033[33;1m")

if A == "YouTube" or A == "NothingYT":
  print
  os.system("sh loding.py")

else:
     print "\033[31;1m\nERROR: Wrong Input Password"
     timeout(0.2)
     restart_program()