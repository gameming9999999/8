blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'   
yellow='\033[33;1m'

echo ""
echo "\033[34;1m[\033[37;1m01\033[34;1m] โหลดแฮ็ก1"
echo "\033[34;1m[\033[37;1m02\033[34;1m] โหลดแฮ็ก2"
echo "\033[34;1m[\033[37;1m03\033[34;1m] โหลดแฮ็ก3"
echo "\033[34;1m[\033[37;1m04\033[34;1m] โหลดแฮ็ก4"
echo "\033[34;1m[\033[37;1m05\033[34;1m] โหลดแฮ็ก5"
echo "                 \033[34;1m[\033[37;1m00\033[34;1m] back"
echo "\033[33;1m"
read -p " select>  " korn


if [ $korn = 1 ] || [ $korn = 01 ]
then
clear
figlet "Nothing" | lolcat
xdg-open https://www.mediafire.com/download/h7uo26thwnyzsab
fi

if [ $korn = 2 ] || [ $korn = 02 ]
then
clear
figlet "Nothing" | lolcat
xdg-open https://www.mediafire.com/download/39g1wipd0e8t0d7
fi

if [ $korn = 3 ] || [ $korn = 03 ]
then
clear
figlet "Nothing" | lolcat
xdg-open https://www.mediafire.com/download/yzkbt20i2s1ysi5
fi

if [ $korn = 4 ] || [ $korn = 04 ]
then
clear
figlet "Nothing" | lolcat
xdg-open https://www.mediafire.com/download/do7eab8b3e4e5ae
fi

if [ $korn = 5 ] || [ $korn = 05 ]
then
clear
figlet "Nothing" | lolcat
xdg-open https://www.mediafire.com/download/q25qxc2yk6aqjkh
fi

if [ $korn = 0 ] || [ $korn = 00 ]
then
clear
figlet "Welcome" | lolcat
sleep 1
cd ..
sh one.sh

fi