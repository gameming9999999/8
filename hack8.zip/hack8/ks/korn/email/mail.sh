blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'   
yellow='\033[33;1m'
figlet "KORNX2 PS" | lolcat
echo ""
echo "\033[34;1m[\033[37;1m01\033[34;1m] ยิงข้อความแบบธรรมดา"
echo "\033[34;1m[\033[37;1m02\033[34;1m] ยิงข้อความแบบเท่ๆ"
echo "                 \033[34;1m[\033[37;1m00\033[34;1m] back"
echo "\033[33;1m"
read -p " select>  " korn


if [ $korn = 1 ] || [ $korn = 01 ]
then
clear
figlet "KornX2" | lolcat
clear
python2 Emailbomb.py

fi


if [ $korn = 2 ] || [ $korn = 02 ]
then
clear
python2 bomb.py
fi

if [ $korn = 0 ] || [ $korn = 00 ]
then
clear
figlet "KornX2" | lolcat
cd ..
cd ..
sh one.sh

fi
