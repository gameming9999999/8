chmod +x ${home}/Sploit
rm -rf ${home}/install.sh
${s} kk.sh
exit
