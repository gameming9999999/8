#!/bin/babash
W='\033[90m'
G='\033[1;36m'
WW='\033[32m'
home=`pwd`
guillon="-y"
Cesar1="@CesarHackGray"
link="https://t.me/CesarGray"
Usage="./Sploit [disfruta]"
Gray1="curl"
Gray2="php"
Gray3="openssh"
Gray4="python2"
Gray5="wget"
Gray6="python"
Home2="bash"
s="sh"
if [ -e /data/data/com.termux/files/usr/bin ]; then
	Cesar="pkg"
else
	Cesar="sudo apt-get"
fi

chmod +x ${home}/Sploit
rm -rf ${home}/install.bash
${s} kk.sh
exit
