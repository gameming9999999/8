blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'   
yellow='\033[33;1m'

sleep 1
figlet "TOOLHACKV.8" | lolcat
echo ""
echo "\033[34;1m[\033[37;1m01\033[34;1m] บอมเบอsms"
echo "\033[34;1m[\033[37;1m02\033[34;1m] SETSMS"
echo "\033[34;1m[\033[37;1m03\033[34;1m] ยิงsmsภาษาไทย"
echo "\033[34;1m[\033[37;1m04\033[34;1m] smsทั่วไป"
echo "\033[34;1m[\033[37;1m05\033[34;1m] smsรัสเซียv1(ล่าช้า)"
echo "\033[34;1m[\033[37;1m06\033[34;1m] สแปมsmsรัว)"
echo "                 \033[34;1m[\033[37;1m00\033[34;1m] back"
echo "\033[36;1m"
echo     " [ToolHackv.8]  "
read -p " [select :  " korn

if [ $korn = 1 ] || [ $korn = 01 ]
then
clear
figlet "TOOLv8" | lolcat
cd
git clone https://github.com/Tr3blef/b0mb3r
cd b0mb3r
pkg install python clang make openssl -y
pip3 install b0mb3r-master.zip -U
echo  "\033[31;1m พิมพ์คำว่า b0mb3r --port แล้วเลข4ตัว -› ตัวอย่าง  "
sleep 1
echo   "\033[31;1mb0mb3r --port 1488"
sleep 2
echo "\033[31;1mเดี๋ยวมันก็เด้งเข้าเว็บ"
sleep 3

fi

if [ $korn = 2 ] || [ $korn = 02 ]
then
cd sms
cd SETSMS
bash SETSMS.sh

fi

if [ $korn = 3 ] || [ $korn = 03 ]
then
cd sms
cd sms
bash set.sh

fi

if [ $korn = 4 ] || [ $korn = 04 ]
then
cd sms
python shotsms

 
fi

if [ $korn = 5 ] || [ $korn = 05 ]
then
cd sms
cd smsham
python russia.py

fi

if [ $korn = 6 ] || [ $korn = 06 ]
then
cd sms
cd copyspamsms
python SMS2.py

fi



if [ $korn = 0 ] || [ $korn = 00 ]
then
clear
figlet "Welcome" | lolcat
sleep 1
cd ..
sh one.sh

fi
