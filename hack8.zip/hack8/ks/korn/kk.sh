blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'                      yellow='\033[33;1m'
clear
echo "      ░█▀▀█ █──█ █▀▀ █▀▀ █─█ 　 █▀▀▄ █▀▀█ ▀▀█▀▀ 
      ░█─── █▀▀█ █▀▀ █── █▀▄ 　 █▀▀▄ █──█ ──█── 
      ░█▄▄█ ▀──▀ ▀▀▀ ▀▀▀ ▀─▀ 　 ▀▀▀─ ▀▀▀▀ ──▀──" | lolcat
echo ""
echo $blue "เข้า google chrome แล้วหา ชื่อช่อง Nothing YT แล้วคัดลอกurlช่องมา "
echo $purple "ค้นหา -› m.youtube.com" | lolcat
echo $red "ตรวจสอบว่าคุณเป็น บอท หรือไม่"
echo  "$cyan"
read -p "[+] โทเคนช่อง :  " korn
read -p "[+] URLคริปเก่าสุด  :   " a
echo ""
if [ $korn = UC4EbRMzIhWA57hzYYEzeqaQ ]
then
echo "$yellow ตรวจสอบโทเคน..."
sleep 4
echo $green"[✔]$white โทเคนถูกต้อง"
sleep 1
fi


if [ $korn =   ] || [ $korn =   ]
then
echo "$yellow ตรวจสอบโทเคน..."
sleep 3
echo  $red"[$white✘$red]$whiteโทเคนไม่ถูกต้อง"
sleep 1
sh kk.sh
sleep 3
fi

if [ $a =   ] || [ $a =    ]
then
echo "$yellow ตรวจสอบurl..."
sleep 3
echo  $red"[$white✘$red]$white urlไม่ถูกต้อง"
sleep 1
sh kk.sh
sleep 3
fi

if [ $a = https://youtu.be/mPj6M6jiuuc ]
then
echo "$yellow ตรวจสอบurl..."
sleep 4
echo $green"[✔]$white urlถูกต้อง"
sleep 1
clear
figlet "Download" | lolcat
sh down.sh
sleep 3
fi

if [ $korn =   ] || [ $korn =   ]
then
echo "$yellow ตรวจสอบโทเคน..."
sleep 3
echo  $red"[$white✘$red]$whiteโทเคนไม่ถูกต้อง"
sleep 1
sh kk.sh
sleep 3
fi

function Error {
echo "$yellow ตรวจสอบโทเคน..."
sleep 4
echo  $red"[$white✘$red]$whiteโทเคนไม่ถูกต้อง"
sleep 1
echo "$yellow ตรวจสอบurl..."
sleep 3
echo  $red"[$white✘$red]$white urlไม่ถูกต้อง"
sleep 1
sh kk.sh
sleep 4