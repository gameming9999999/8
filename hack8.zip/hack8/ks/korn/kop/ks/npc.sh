blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'                                           
yellow='\033[33;1m'

 echo "รอแปปนึงบักหำน้อย..... "
sleep 7.0
clear 
                                
 
        echo "\033[1;32mรอแปป ==+[->][\] 1%" KornX2 PS 
sleep 2.0
clear
       echo "\033[1;32mรอแปป ==+[-->][/] 27%" KornX2 PS
sleep 1.4
clear
       echo "\033[1;32mรอแปป ==+[--->][\] 33% "KornX2 PS
sleep 1.5
clear
       echo "\033[1;32mรอแปป ==+[---->][\] 46% "KornX2 PS
sleep 1.3
clear
       echo "\033[1;32mรอแปป ==+[------>][/] 50% "KornX2 PS
sleep 1.0
clear
       echo "\033[1;32mรอแปป ==+[---------->][\] 58% "KornX2 PS
sleep 3.0
clear
       echo "\033[1;32mรอแปป ==+[------------>][/] 61% " korn
sleep 1.5
clear
       echo "\033[1;32mรอแปป ==+[------------------>] [\] 71%" KornX2 PS
sleep 3.5
clear
       echo "\033[31;1mรีโหลดแปป==+[------------------>]\033[1;32m[/] 76%" KornX2 PS
sleep 1.0
clear
       echo "\033[31;1mรีโหลดแปป ==+[------------------->]\033[1;32m[\] 84%" KornX2 PS
sleep 1.0
clear
         echo "\033[31;1mรีโหลดแปป ==+[--------------------->]\033[1;32m[/] 91%" KornX2 PS
sleep 1.0
clear
         echo "\033[31;1mรีโหลดแปป ==+[----------------------->]\033[1;32m[✓] 100%" KornX2 PS
sleep 1.0
clear
       
sleep 4.0


            echo "\033[34;1m ______██████████████
                           -____██▓▓▓▓▓▓▓▓▓ M ▓████
                           -__██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██
                           -__██████░░░░██░░██████
                            ██░░░░████░░██░░░░░░░░██
                            ██░░░░████░░░░██░░░░░░██
                           -__████░░░░░░██████████
                           -__██░░░░░░░░░░░░░██
                            _____██░░░░░░░░░██
                           -______██░░░░░░██
                         -____██▓▓████▓▓▓█
                       -_██▓▓▓▓▓▓████▓▓█
                      ██▓▓▓▓▓▓███░░███░
                       -__██░░░░░░███████
                         -____██░░░░███████
                          -______██████████
                          -_____██▓▓▓▓▓▓▓▓▓██
                          -_____█████████████.  "
echo ""
echo ""
     echo "\033[34;1m[$]\033[36;1m============================\033[34;1m[$]"
     echo "\033[32;1mAuthor : Korn"
     echo "\033[37;1mname   : chaimongkol"
     echo "\033[35;1mversion Tools: v.5"
     echo "\033[35;1mTeam : Hacker"
     echo "\033[33;1mphon number : +66618023699"
     echo "\033[31;1mYoutube: Hacker TH."
     echo "\033[92mDarkness Cyber Team" 
     echo "\033[36;1mThailand Security Lite"
     echo "\033[34;1m[$]\033[36;1m============================\033[34;1m[$]"
echo ""
echo "" 
           echo    "[*] พิมพ์ว่า url แล้ว ENTER "
echo "" 
echo "\033[32;1m"
echo     "[root@Tools] [Download] "
read -p " ~#>  " korn

if [ $korn = url ] || [ $korn = url ]
then
clear
figlet "KornX2" | lolcat

xdg-open https://th.savefrom.net/7/#url=http:/youtube.com/
sh Bot

fi