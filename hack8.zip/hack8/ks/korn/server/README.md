# server

chmod +x setup.sh
sh setup.sh

termux only
