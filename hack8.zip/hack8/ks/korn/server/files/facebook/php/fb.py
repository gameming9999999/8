#python2

def fbcre():
 try:
  target = "files/facebook/php/l.txt"
  file = open(target, "r")
  text = file.read()
  file.close()
  print text
 except IOError:
  print ''
  print "No data found !"
  print ''

