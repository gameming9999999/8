#!/bin/bash
cd modules
bash select.sh
