#!/bin/bash
python2 serphp.py
