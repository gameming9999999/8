# SETSMS
Es una herramienta de automatización de spam de mensajes de texto a un número telefónico de manera gratuita y anónima. Utiliza las herramientas (Quack - Impulse) para realizar el spam, además, tiene la función de guardar números telefónicos en una lista negra (blacklist) y realizar el spam a todos los números de la lista negra consecutivamente.
# DEMO
![alt text](https://github.com/Darkmux/SETSMS/blob/master/SETSMS.png)
# PLATAFORMAS
[√] Termux
#
[√] Kali Linux
#
[√] Parrot Sec
# REQUISITOS
[-] git
#
[-] python3
# INSTALACIÓN
git clone https://github.com/Darkmux/SETSMS
#
cd SETSMS
#
chmod 777 SETSMS.sh
#
bash SETSMS.sh
# Creado por Darkmux
# ©WHITE HACKS
