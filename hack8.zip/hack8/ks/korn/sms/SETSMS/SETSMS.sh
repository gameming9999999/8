#!/bin/bash
#
# SETSMS: (26/01/2021)
#
# [Open Source] - [Código Abierto]
#
# Variables y Colores
#
PWD=$(pwd)
OS=$(uname -o)
USER=$(id -u)
verde='\033[32m'
blanco='\033[37m'
rojo='\033[31m'
azul='\033[34m'
negro='\033[0;30m'
rosa='\033[38;5;207m'
amarillo='\033[33m'
morado='\033[35m'
cian='\033[1;36m'
magenta='\033[1;35m'
#
# Dependencias del Script
#
function Dependencies {
if [ "${OS}" == "Android" ]; then
  if [ -x ${PREFIX}/bin/python ]; then
    RUTA=$(pwd)
  else
    RUTA=$(pwd)
    pkg update && pkg upgrade -y
    pkg install python -y
    pip install --upgrade pip
  fi
  if [ -x ${PWD}/quack ]; then
    RUTA=$(pwd)
  else
    RUTA=$(pwd)
    unzip quack.zip
    rm quack.zip
    cd ${RUTA}/quack
    python3 -m pip install -r requirements.txt
    cd ${RUTA}
  fi
  if [ -x ${PWD}/Impulse ]; then
    RUTA=$(pwd)
  else
    RUTA=$(pwd)
    unzip Impulse.zip
    rm Impulse.zip
    cd ${RUTA}/Impulse
    python3 -m pip install -r requirements.txt
    cd ${RUTA}
  fi
else
  if [ -x /bin/python3 ]; then
    RUTA=$(pwd)
  else
    RUTA=$(pwd)
    apt-get update && apt-get upgrade -y
    apt-get install python3 -y
  fi
  if [ -x ${PWD}/quack ]; then
    RUTA=$(pwd)
  else
    RUTA=$(pwd)
    unzip quack.zip
    rm quack.zip
    cd ${RUTA}/quack
    python3 -m pip install -r requirements.txt
    cd ${RUTA}
  fi
  if [ -x ${PWD}/Impulse ]; then
    RUTA=$(pwd)
  else
    RUTA=$(pwd)
    unzip Impulse.zip
    rm Impulse.zip
    cd ${RUTA}/Impulse
    python3 -m pip install -r requirements.txt
    cd ${RUTA}
  fi
fi
}
#
# Mensaje de Opción Incorrecta
#
function Error {
echo -e "${rojo}

 ${blanco}[\033[31m✘\033[37;1m]\033[31mเกิดข้อผิดพลาดคุณใส่หมายเลขผิดหรือAIไม่เข้าใจ ${rojo}
"${blanco}
sleep 7.5
}
#
# Banner SETSMS
#
function SETSMS {
  sleep 0.5
  clear
echo -e "${verde}
███████╗███████╗████████╗███████╗███╗   ███╗███████╗
██╔════╝██╔════╝╚══██╔══╝██╔════╝████╗ ████║██╔════╝
███████╗█████╗     ██║   ███████╗██╔████╔██║███████╗
╚════██║██╔══╝     ██║   ╚════██║██║╚██╔╝██║╚════██║
███████║███████╗   ██║   ███████║██║ ╚═╝ ██║███████║
╚══════╝╚══════╝   ╚═╝   ╚══════╝╚═╝     ╚═╝╚══════╝"${blanco}
}
#
# Menu Principal
#
function Choose {
SETSMS
echo -e -n "${verde}
┌═══════════════════════┐
█ ${blanco}เลือกตัวเลือก            ${verde}█
└═══════════════════════┘
┃     ┌══════════════════════┐
└═>>> █ ${blanco}สคริปต์แปลไทย          ${verde}█
┃     └══════════════════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ [${blanco}01${verde}] ┃ ${blanco}สแปมsms + call                     ${verde}█
┃    └═══════════════════════════════════════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ [${blanco}02${verde}] ┃ ${blanco}บันทึก 1 หมายเลขในบัญชีดำ              ${verde}█
┃    └═══════════════════════════════════════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ [${blanco}03${verde}] ┃ ${blanco}หมายเลขบัญชีดำของสแปมเมอร์            ${verde}█
┃    └═══════════════════════════════════════════┘
┃    ┌═══════════════════════════════════════════┐
└═>>>█ [${blanco}04${verde}] ┃ ${blanco}ดูตัวเลขในบัญชีดำ                      ${verde}█
┃    └═══════════════════════════════════════════┘
┃    ┌══════════════┐
└═>>>█ [${blanco}00${verde}] ┃ ${rojo}ออก   ${verde}█
┃    └══════════════┘
┃
└═>>> "${blanco}
read -r OPTION
sleep 0.5

if [[ ${OPTION} == 0 || ${OPTION} == 00 ]]; then
exit
elif [[ ${OPTION} == 1 || ${OPTION} == 01 ]]; then
source ${RUTA}/tools/target.sh
elif [[ ${OPTION} == 2 || ${OPTION} == 02 ]]; then
source ${RUTA}/tools/save.sh
elif [[ ${OPTION} == 3 || ${OPTION} == 03 ]]; then
source ${RUTA}/tools/spam.sh
elif [[ ${OPTION} == 4 || ${OPTION} == 04 ]]; then
source ${RUTA}/tools/list.sh

elif [[ ${OPTION} == หี || ${OPTION} == Hee ]]; then

echo -e "${rojo}
${blanco}AI: หีพ่อหีแม่มึงอ่ะแล้วเป็นควยไรกลับไปชักว่าวไปจะได้หายเงี่ยน${rojo}
"${blanco}
sleep 0.5
figlet "i kuy" | lolcat
sleep 6
bash SETSMS.sh

elif [[ ${OPTION} == ทำไง || ${OPTION} == มันทำไง ]]; then

echo -e "${rojo}
${blanco}AI: เลือกหมายเลขที่ต้องไงถ้าต้องการแกล้งเพื่อนหรือปั่นแนะนำ1มันจะยิงรหัสOTP+โทรด้วยครับ${rojo}
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == กร || ${OPTION} == korn ]]; then

echo -e "${rojo}
 ${blanco}AI: เค้าแม้งโครตโหดโครตเก่งเลย
 AI: เล่นเกมไรก็ยืน1${rojo}
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == ควย || ${OPTION} == KUY  ]]; then

echo -e "${rojo}
${blanco}AI: แล้วมึงเป็นควยไรละสาสสส${rojo}
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == ลี้ || ${OPTION} == ตี้  ]]; then

echo -e "${rojo}
${blanco}AI: อ๋อขี้ใช่ป่ะเพื่อนอาจารย์ผม
 AI: จารชอบบอกผมว่าไอตี้มันเล่นกากต้องให้จารแบกจารนี้เก่งจริงๆ${rojo}
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == วิธีใช้ || ${OPTION} == วิธีใช้งาน  ]]; then

echo -e "${rojo}
${blanco}AI: กด1แล้วกด ENTER หลังจากนั้นก็ใส่เบอร์ +66แทนศูนย์นะครับ😚${rojo}
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == ควย || ${OPTION} == Kuy ]]; then

echo -e "${rojo}
${blanco}AI: แล้วมึงเป็นควยไรละสาสสส${rojo}
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == AI || ${OPTION} == แนะนำตัว ]]; then

echo -e "${rojo}
${blanco}AI: ชื่อ ปีเตอร์ ครับ อายุ70 อยู่ ป.2 ชอบกินมาม่า
 AI: เป็นผู้ช่วยครับ อยู่รัสเซีย อินเดีย อินโดนีเซีย จอเจียร์ ซาอุดีอาระเบีย บราซิเลีย${rojo}
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == ใครฉลาดสุด|| ${OPTION} == ใครเก่ง ]]; then

echo -e "${rojo}
${blanco}ปีเตอร์ : phi korn ไงครับถามแปลก>
"${blanco}
sleep 10
bash SETSMS.sh

elif [[ ${OPTION} == รันะครับ || ${OPTION} == ชอบนะครับ ]]; then

echo -e "${rojo}
${blanco}ปีเตอร์ : 😚😳😳>
"${blanco}
sleep 10
bash SETSMS.sh

else
Error
Choose
fi
}
#
# Declarando Funciones
#
Dependencies
Choose
