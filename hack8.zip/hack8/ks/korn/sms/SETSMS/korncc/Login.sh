banner () {
clear

echo""
echo""
echo""
echo""
echo""
echo""
echo""
echo""
echo"" 
echo""
echo""
echo""
echo""
echo  ' 
                                _  __              _____ _   _
                               | |/ /___  _ __ _ _|_   _| | | |
                               | ' // _ \| '__| '_ \| | | |_| |                               | . \ (_) | |  | | | | | |  _  |
                               |_|\_\___/|_|  |_| |_|_| |_| |_| 
'                               
echo""
echo""
echo""
echo""
echo "               "/█1%...................../
sleep 2.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  ' 
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/█4%....................../
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '

                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/█8%......................./
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/██10%....................../
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo ' 
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/██12%....................../
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/███15%..................../
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo ' 
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "               "/█████19%..................../
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "               "/██████28%..................../
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/████████30%................../
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/██████████40%................/
sleep 1.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/█████████████50%............./
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/████████████████60%........../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo "                "/███████████████████88%......./
sleep 5.0

clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
clear
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
      figlet By Punit | lolcat
echo ""
echo "" 
echo "               "[██████████████████████ 100%]
echo ""
echo ""
echo ""
echo ""
echo ""
echo "" 


}
content () {
sleep 3
clear
echo -e "\e[1;32m

 
'██╗░░░░░░█████╗░░██████╗░██╗███╗░░██╗
██║░░░░░██╔══██╗██╔════╝░██║████╗░██║
██║░░░░░██║░░██║██║░░██╗░██║██╔██╗██║
██║░░░░░██║░░██║██║░░╚██╗██║██║╚████║
███████╗╚█████╔╝╚██████╔╝██║██║░╚███║
╚══════╝░╚════╝░░╚═════╝░╚═╝╚═╝░░╚══╝
'     


\e[1;35m
[+] Author : ♣♠Yours Punit♠|♣
[+] Team : Hackers
[+] Github : https://www.github.com/Punit-art
\e[0m"
}
menu () {
content
read -p $'\e[1;31mEnter Username for Login :\e[0m ' username
read -p $'\e[1;32mEnter Password for Login :\e[0m ' password

cd
cd /sdcard
cd Download/SETSMS/korncc
rm motd
rm bash.bashrc
cat <<LOGIN>bash.bashrc
trap '' 2
echo -e "\e[1;32m
                ──▄▀▀▀▄───────────────
                ล็อคอิน computer lock
                ──█───█───────────────
                ─███████─────────▄▀▀▄─
                ░██─▀─██░░█▀█▀▀▀▀█░░█░
                ░███▄███░░▀░▀░░░░░▀▀░░
\e[0m"
read -p $'\e[32mInput Username :\e[0m ' user
read -s -p $'\e[32mInput Password :\e[0m ' pass
if [[ \$pass == $password && \$usr == $username ]]; then
PS1='\[\e[1;34m
\a┌──\a─T─I─M─E─\a──┐\033[1;34m\a┌──\a─D─A─T─E─\a───>\033[1;34m
\a┌─[\033[1;93m \@\033[1;34m ]──[\033[1;93m \d\033[1;34m ]\033[1;34m
\a├─[\033[1;32m\w\033[1;34m]\033[1;34m
\[\e[34m\]└─>\[\e[35m\]$usr\[\e[34m\][~]:#\[\e[1;32m\] '
shopt -s autocd
shopt -s cdspell
shopt -s checkhash
shopt -s checkwinsize
shopt -s compat31
shopt -s compat32
shopt -s compat40
shopt -s compat41
shopt -s no_empty_cmd_completion
shopt -s histverify
shopt -s histappend
shopt -s dirspell
shopt -s direxpand
shopt -s compat43
shopt -s compat32
shopt -s lithist
clear
banner
else
echo ""
echo -e "\e[1;31m  Your Password Is Incorrect
\e[0m"
sleep 1
cmatrix -L
fi
trap 2
LOGIN
echo -e "\e[1;32m Termux is ready exit and Login \e[0m"

}
banner
menu
