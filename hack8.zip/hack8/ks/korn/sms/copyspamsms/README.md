
 git clone https://github.com/COOL4C4/THE-SMS2
![20210827_124025](https://user-images.githubusercontent.com/74477764/131134725-2d9cca4f-92a7-4219-8e95-1787f509c65b.jpg)

 pkg upgrade && pkg update

 pip3 install requests

 pip3 install colorama

 pkg install python

 termux-setup-storage

 termux-setup-storage

 dpkg --configure -a

 dpkg --configure -a
