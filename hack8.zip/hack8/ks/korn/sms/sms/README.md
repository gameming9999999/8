# SMS
ยิงข้อความตัวไหม่

git clone https://github.com/tatajub11465/SMS/

cd SMS




sh set.sh

😉😉😉😉😉😉😉😉😉
