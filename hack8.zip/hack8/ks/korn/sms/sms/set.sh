echo " ติดตั้งโมดูลรอสักครู่ "
echo ""
pip3 install requests
pip3 install colorama
pkg install figlet -y
echo ""
echo "กำลังเปิด"
python3 SMS.py