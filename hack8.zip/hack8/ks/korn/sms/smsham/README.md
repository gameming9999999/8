# smsham Made in Termux-Lab
python3<br>
# pip
requests<br>
colorama<br>
# install and use
git clone https://github.com/termux-lab/smsham.git
cd smsham<br>
python3 smsham.py<br>
>> number phone

