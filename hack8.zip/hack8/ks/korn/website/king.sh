#colors
g='\033[1;32m'
p='\033[1;35m'                                                          
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install


sleep 0.1 
echo -e " $red                                         [0]back"
sleep 0.1
echo -e "$purple"
sleep 0.1
echo "             [1]dos attack🌎"           "     [6]Dork Google"
sleep 0.1
echo "             [2]admin panel finder "
sleep 0.1
echo "             [3]open Xshell"
sleep 0.1
echo "             [4]Hash id 1"
sleep 0.1
echo "             [5]Hack sql "
sleep 0.1
echo ""
sleep 0.1
echo -e "$green"
sleep 0.1
read -p " select>  " korn

if [ $korn = 1 ] || [ $korn = 01 ]
then
bash dos.sh

fi

if [ $korn =  2 ] || [ $korn = 02 ]
then
bash admin.sh


fi

if [ $korn = 3 ] || [ $korn = 03 ]
then
clear
figlet "KornX2" | lolcat
cd Xshell
python xshell.py

fi

if [ $korn = 4 ] || [ $korn = 04 ]
then
clear
figlet "KornX2" | lolcat
bash ha.sh


fi

if [ $korn = 5 ] || [ $korn = 05 ]
then
clear
figlet "KornX2" | lolcat
bash sql.sh

fi

if [ $korn = 6 ] || [ $korn = 06 ]
then
clear
figlet "KornX2" | lolcat
bash dork.sh



fi

if [ $korn = ] || [ $korn =  ]
then
clear
echo " Something went wrong"
sleep 1
bash king.sh

fi

if [ $korn = 0 ] || [ $korn = 00 ]
then
cd ..
cd ..
sh one.sh

fi


