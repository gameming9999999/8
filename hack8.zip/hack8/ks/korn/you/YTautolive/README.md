# YTautolive
ScriptKing SCK

    
                 <> UPdate api new Proxy <>




  ขั้นตอนการติดตั้งใน Termux
  
  pkg install pyhton
  
  
  pkg install git   
  
  
  git clone https://github.com/scriptkingSCK/YTautolive
  
  
  
  cd YTautolive
  
  
  
  chmod +x *
  
 bash set.sh
 
  bash menu.sh
  

   <H1> แฮ่มมม เทรดคือPortน่ะครับ จะใส่ 8080 80 3128 แล้วแต่เลยจนกว่าเทรดนั้นจะหยุด </> 
   <H1>

((  ไอดีวิดีโอไฟล์สดตัวอย่าง https://youtu.be/JTpAnQCjFpc คัดลอกแค่ JTpAnQCjFpc ))
