pip install requests
  pip install requirements.txt

  pip install colorama
  
  echo "เปิดพิม Enter1ครั้ง"
  read a6
bash menu.sh
  
